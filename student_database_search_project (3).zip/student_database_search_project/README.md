# Student Database Search System

## About the project

This is a simple project for keeping student details in one place. It can be used to add new student information, find a student, see all saved records, change details, or remove a record.

The same project is made in four programming languages:
- Python
- Java
- C
- C++

All four programs use the same file named `students.csv`. This file stores the student ID, name, course, and email address.

## What can this project do?

1. Show all students saved in the file.
2. Search for a student using their ID, name, course, or email.
3. Add a new student's details.
4. Change the details of an existing student.
5. Delete a student record.

## Files in this project

```text
student-database-search/
│
├── README.md
├── students.csv
├── python/
│   └── main.py
├── java/
│   └── StudentDatabase.java
├── c/
│   └── main.c
└── cpp/
    └── main.cpp
```

## What you need

Install the tools for the language you want to run:

- Python 3 to run the Python program.
- Java JDK to run the Java program.
- GCC to compile the C program.
- G++ to compile the C++ program.

## How to run the programs

Open a terminal in the main project folder.

### Python

```bash
python python/main.py
```

### Java

```bash
java java/StudentDatabase.java
```

If that command does not work, compile and run it like this:

```bash
javac java/StudentDatabase.java
java -cp java StudentDatabase
```

### C

```bash
gcc c/main.c -o student_db_c
./student_db_c
```

On Windows, run `student_db_c.exe` after compiling.

### C++

```bash
g++ cpp/main.cpp -o student_db_cpp
./student_db_cpp
```

On Windows, run `student_db_cpp.exe` after compiling.

Run the commands from the main project folder so that each program can find `students.csv`.

## Try the project

When the program starts, it shows a menu.

- Choose `1` to see all student records.
- Choose `2` to search for a student. You can enter a name, ID, course, or email.
- Choose `3` to add a student.
- Choose `4` to change a student's details.
- Choose `5` to delete a student.
- Choose `0` to close the program.

For example, choose `2` and type `Meera`. The program should show the record for Meera Thakur.

You can also try searching with an ID such as `1003` or a course such as `BCA`.

## How the search works

The program reads the student details from `students.csv`. It checks the text you enter against the saved ID, name, course, and email. It can find part of a word and does not depend on capital or small letters.

## How to put the project on GitHub

1. Sign in to GitHub and create a new repository.
2. Give it a name such as `student-database-search`.
3. Upload the project folders, `students.csv`, and this README file.
4. Open the repository to see the code and project details.

## What I learned

While making this project, I practised using conditions, loops, functions, file handling, and searching in different programming languages. I also learned how to save information in a file and work with it later.

## A note about the data file

This is a small learning project. It uses a CSV file instead of a full database system. Keep each field simple and do not use commas inside names, courses, or email addresses.
