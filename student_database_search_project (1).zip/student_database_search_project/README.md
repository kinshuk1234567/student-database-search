# Student Database Search Management System

A beginner-friendly, GitHub-ready project demonstrating record management and searching in **Python, Java, C, and C++**.

## Features
- Display all student records
- Search by partial or complete ID, name, course, or email (case-insensitive)
- Add, update, and delete records
- Save data in a shared `students.csv` file so all four versions use the same data

## Project structure
```text
student_database_search_project/
├── students.csv
├── README.md
├── python/main.py
├── java/StudentDatabase.java
├── c/main.c
└── cpp/main.cpp
```

## Requirements
- Python 3
- Java JDK (for `java` and `javac`)
- GCC for C
- G++ for C++

## Run from the project root folder

### Python
```bash
python python/main.py
```

### Java
```bash
java java/StudentDatabase.java
```
If source-file launch is unavailable:
```bash
javac java/StudentDatabase.java
java -cp java StudentDatabase
```

### C
```bash
gcc c/main.c -o student_db_c
./student_db_c
```
On Windows Command Prompt, run `student_db_c.exe` instead.

### C++
```bash
g++ cpp/main.cpp -o student_db_cpp
./student_db_cpp
```
On Windows Command Prompt, run `student_db_cpp.exe` instead.

**Important:** Run each program from the project root directory. This ensures each language reads and writes the same `students.csv` file.

## Try it
1. Choose `1` to display the sample records.
2. Choose `2` and search for `Meera`, `1003`, or `BCA`.
3. Choose `3` to add a record.
4. Choose `4` to update a record by ID.
5. Choose `5` to delete a record by ID.

## How searching works
Each program reads the CSV rows and checks whether the search text occurs in any field. The search ignores letter case, so `meera` and `MEERA` both find Meera Thakur.

## GitHub upload
1. Create a new repository on GitHub, for example `student-database-search`.
2. Extract this ZIP file.
3. Open the extracted folder in VS Code or a terminal.
4. Initialize Git and push:
```bash
git init
git add .
git commit -m "Add student database search project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-database-search.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.

## Learning note / limitations
This is an educational file-based database project, not a production database. It uses simple comma-separated fields; commas inside names or other values are not supported. For a larger real application, consider SQLite or MySQL, input validation, authentication, and safer concurrent file handling.
