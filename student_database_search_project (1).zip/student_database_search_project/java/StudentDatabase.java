import java.io.*;
import java.nio.file.*;
import java.util.*;

public class StudentDatabase {
    private static final Path DB = Paths.get("students.csv");
    private static final String HEADER = "ID,Name,Course,Email";
    private static final Scanner in = new Scanner(System.in);

    static List<String[]> readRecords() throws IOException {
        List<String[]> rows = new ArrayList<>();
        if (!Files.exists(DB)) Files.writeString(DB, HEADER + System.lineSeparator());
        List<String> lines = Files.readAllLines(DB);
        for (int i = 1; i < lines.size(); i++) {
            String[] p = lines.get(i).split(",", -1);
            if (p.length == 4) rows.add(p);
        }
        return rows;
    }
    static void writeRecords(List<String[]> rows) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add(HEADER);
        for (String[] r : rows) lines.add(String.join(",", r));
        Files.write(DB, lines);
    }
    static void show(List<String[]> rows) {
        if (rows.isEmpty()) { System.out.println("No matching records found."); return; }
        System.out.printf("%-10s %-22s %-12s %s%n", "ID", "NAME", "COURSE", "EMAIL");
        System.out.println("--------------------------------------------------------------------");
        for (String[] r : rows)
            System.out.printf("%-10s %-22s %-12s %s%n", r[0], r[1], r[2], r[3]);
    }
    static String ask(String prompt) {
        System.out.print(prompt);
        return in.nextLine().trim();
    }
    static boolean valid(String[] r) {
        for (String s : r) if (s.isBlank() || s.contains(",")) return false;
        return true;
    }
    static void add() throws IOException {
        List<String[]> rows = readRecords();
        String[] r = {ask("Student ID: "), ask("Name: "), ask("Course: "), ask("Email: ")};
        if (!valid(r)) { System.out.println("All fields are required; commas are not allowed."); return; }
        for (String[] old : rows) if (old[0].equals(r[0])) {
            System.out.println("ID already exists."); return;
        }
        rows.add(r); writeRecords(rows); System.out.println("Record added.");
    }
    static void search() throws IOException {
        String q = ask("Search by ID, name, course, or email: ").toLowerCase();
        List<String[]> found = new ArrayList<>();
        for (String[] r : readRecords())
            for (String value : r) if (value.toLowerCase().contains(q)) { found.add(r); break; }
        show(found);
    }
    static void update() throws IOException {
        List<String[]> rows = readRecords();
        String id = ask("ID to update: ");
        for (String[] r : rows) if (r[0].equals(id)) {
            String[] labels = {"Name", "Course", "Email"};
            for (int i = 1; i < 4; i++) {
                String v = ask(labels[i-1] + " [" + r[i] + "]: ");
                if (!v.isEmpty()) {
                    if (v.contains(",")) { System.out.println("Comma not allowed; update cancelled."); return; }
                    r[i] = v;
                }
            }
            writeRecords(rows); System.out.println("Record updated."); return;
        }
        System.out.println("ID not found.");
    }
    static void delete() throws IOException {
        List<String[]> rows = readRecords();
        String id = ask("ID to delete: ");
        boolean removed = rows.removeIf(r -> r[0].equals(id));
        if (removed) { writeRecords(rows); System.out.println("Record deleted."); }
        else System.out.println("ID not found.");
    }
    public static void main(String[] args) throws IOException {
        readRecords();
        while (true) {
            System.out.println("\\n=== STUDENT DATABASE SEARCH SYSTEM ===");
            System.out.println("1. Display all records\\n2. Search records\\n3. Add record");
            System.out.println("4. Update record\\n5. Delete record\\n0. Exit");
            String choice = ask("Choose an option: ");
            switch (choice) {
                case "1": show(readRecords()); break;
                case "2": search(); break;
                case "3": add(); break;
                case "4": update(); break;
                case "5": delete(); break;
                case "0": System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }
}
