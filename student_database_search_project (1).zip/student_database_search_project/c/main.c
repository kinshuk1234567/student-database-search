#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define DB "students.csv"
#define TEMP "students_tmp.csv"
#define MAX 512

typedef struct { char id[64], name[128], course[64], email[128]; } Student;

int load(Student a[], int cap) {
    FILE *f = fopen(DB, "r");
    if (!f) {
        f = fopen(DB, "w");
        if (f) { fprintf(f, "ID,Name,Course,Email\n"); fclose(f); }
        return 0;
    }
    char line[MAX]; int n = 0;
    fgets(line, sizeof line, f); /* header */
    while (n < cap && fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = 0;
        char *p = strtok(line, ","); if (!p) continue; snprintf(a[n].id, sizeof a[n].id, "%s", p);
        p = strtok(NULL, ","); if (!p) continue; snprintf(a[n].name, sizeof a[n].name, "%s", p);
        p = strtok(NULL, ","); if (!p) continue; snprintf(a[n].course, sizeof a[n].course, "%s", p);
        p = strtok(NULL, ","); if (!p) continue; snprintf(a[n].email, sizeof a[n].email, "%s", p);
        n++;
    }
    fclose(f); return n;
}
void save(Student a[], int n) {
    FILE *f = fopen(DB, "w"); if (!f) { puts("Could not write database."); return; }
    fprintf(f, "ID,Name,Course,Email\n");
    for (int i=0;i<n;i++) fprintf(f,"%s,%s,%s,%s\n",a[i].id,a[i].name,a[i].course,a[i].email);
    fclose(f);
}
void input(const char *prompt, char *out, size_t size) {
    printf("%s", prompt); if (!fgets(out, (int)size, stdin)) { out[0]=0; return; }
    out[strcspn(out, "\r\n")] = 0;
}
void show(Student a[], int n) {
    if (!n) { puts("No records found."); return; }
    printf("%-10s %-22s %-12s %s\n", "ID","NAME","COURSE","EMAIL");
    puts("--------------------------------------------------------------------");
    for (int i=0;i<n;i++) printf("%-10s %-22s %-12s %s\n",a[i].id,a[i].name,a[i].course,a[i].email);
}
int contains_ci(const char *s, const char *q) {
    if (!*q) return 1;
    size_t n = strlen(q);
    for (; *s; s++) {
        size_t i=0; while (i<n && s[i] && tolower((unsigned char)s[i])==tolower((unsigned char)q[i])) i++;
        if (i==n) return 1;
    }
    return 0;
}
int main(void) {
    Student a[500]; char choice[32], q[128]; int n=load(a,500);
    for (;;) {
        puts("\n=== STUDENT DATABASE SEARCH SYSTEM ===");
        puts("1. Display all records\n2. Search records\n3. Add record\n4. Update record\n5. Delete record\n0. Exit");
        input("Choose an option: ",choice,sizeof choice);
        if (!strcmp(choice,"1")) show(a,n);
        else if (!strcmp(choice,"2")) {
            input("Search by ID, name, course, or email: ",q,sizeof q);
            Student found[500]; int k=0;
            for(int i=0;i<n;i++) if(contains_ci(a[i].id,q)||contains_ci(a[i].name,q)||contains_ci(a[i].course,q)||contains_ci(a[i].email,q)) found[k++]=a[i];
            show(found,k);
        } else if (!strcmp(choice,"3")) {
            Student s; input("Student ID: ",s.id,sizeof s.id);
            int exists=0; for(int i=0;i<n;i++) if(!strcmp(a[i].id,s.id)) exists=1;
            if(exists || !*s.id || n>=500) { puts("ID exists, is empty, or database is full."); continue; }
            input("Name: ",s.name,sizeof s.name); input("Course: ",s.course,sizeof s.course); input("Email: ",s.email,sizeof s.email);
            if(!*s.name||!*s.course||!*s.email||strchr(s.id,',')||strchr(s.name,',')||strchr(s.course,',')||strchr(s.email,',')) { puts("All fields required; commas not allowed."); continue; }
            a[n++]=s; save(a,n); puts("Record added.");
        } else if (!strcmp(choice,"4")) {
            input("ID to update: ",q,sizeof q); int i;
            for(i=0;i<n;i++) if(!strcmp(a[i].id,q)) break;
            if(i==n) { puts("ID not found."); continue; }
            char v[128]; input("New name (blank keeps current): ",v,sizeof v); if(*v) snprintf(a[i].name,sizeof a[i].name,"%s",v);
            input("New course (blank keeps current): ",v,sizeof v); if(*v) snprintf(a[i].course,sizeof a[i].course,"%s",v);
            input("New email (blank keeps current): ",v,sizeof v); if(*v) snprintf(a[i].email,sizeof a[i].email,"%s",v);
            save(a,n); puts("Record updated.");
        } else if (!strcmp(choice,"5")) {
            input("ID to delete: ",q,sizeof q); int i;
            for(i=0;i<n;i++) if(!strcmp(a[i].id,q)) break;
            if(i==n) puts("ID not found.");
            else { for(int j=i;j<n-1;j++) a[j]=a[j+1]; n--; save(a,n); puts("Record deleted."); }
        } else if (!strcmp(choice,"0")) { puts("Goodbye!"); break; }
        else puts("Invalid option.");
    }
    return 0;
}
