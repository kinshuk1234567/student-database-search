import csv
from pathlib import Path

DB = Path(__file__).resolve().parent.parent / "students.csv"
FIELDS = ["ID", "Name", "Course", "Email"]

def read_records():
    with DB.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def write_records(records):
    with DB.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)

def show(records):
    if not records:
        print("No matching records found.")
        return
    print(f'{"ID":<10} {"NAME":<22} {"COURSE":<12} EMAIL')
    print("-" * 68)
    for r in records:
        print(f'{r["ID"]:<10} {r["Name"]:<22} {r["Course"]:<12} {r["Email"]}')

def add_record():
    records = read_records()
    sid = input("Student ID: ").strip()
    if not sid or any(r["ID"] == sid for r in records):
        print("ID is empty or already exists.")
        return
    name = input("Name: ").strip()
    course = input("Course: ").strip()
    email = input("Email: ").strip()
    if not all([name, course, email]) or any("," in x for x in [sid, name, course, email]):
        print("All fields are required; commas are not allowed.")
        return
    records.append(dict(zip(FIELDS, [sid, name, course, email])))
    write_records(records)
    print("Record added.")

def search_records():
    term = input("Search by ID, name, course, or email: ").strip().casefold()
    matches = [r for r in read_records()
               if any(term in value.casefold() for value in r.values())]
    show(matches)

def update_record():
    records = read_records()
    sid = input("ID to update: ").strip()
    for r in records:
        if r["ID"] == sid:
            for field in FIELDS[1:]:
                value = input(f'{field} [{r[field]}]: ').strip()
                if value:
                    if "," in value:
                        print("Commas are not allowed; update cancelled.")
                        return
                    r[field] = value
            write_records(records)
            print("Record updated.")
            return
    print("ID not found.")

def delete_record():
    records = read_records()
    sid = input("ID to delete: ").strip()
    remaining = [r for r in records if r["ID"] != sid]
    if len(remaining) == len(records):
        print("ID not found.")
    else:
        write_records(remaining)
        print("Record deleted.")

def main():
    if not DB.exists():
        write_records([])
    while True:
        print("\\n=== STUDENT DATABASE SEARCH SYSTEM ===")
        print("1. Display all records\\n2. Search records\\n3. Add record")
        print("4. Update record\\n5. Delete record\\n0. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "1": show(read_records())
        elif choice == "2": search_records()
        elif choice == "3": add_record()
        elif choice == "4": update_record()
        elif choice == "5": delete_record()
        elif choice == "0":
            print("Goodbye!")
            break
        else: print("Invalid option. Try again.")

if __name__ == "__main__":
    main()
