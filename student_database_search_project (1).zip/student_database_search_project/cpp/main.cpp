#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

const string DB = "students.csv";
struct Student { string id, name, course, email; };

vector<Student> load() {
    ifstream in(DB);
    if (!in) { ofstream create(DB); create << "ID,Name,Course,Email\n"; return {}; }
    string line; getline(in, line); vector<Student> rows;
    while (getline(in, line)) {
        stringstream ss(line); Student s;
        if (getline(ss,s.id,',') && getline(ss,s.name,',') &&
            getline(ss,s.course,',') && getline(ss,s.email,',')) rows.push_back(s);
    }
    return rows;
}
void save(const vector<Student>& rows) {
    ofstream out(DB);
    out << "ID,Name,Course,Email\n";
    for (const auto& s : rows) out << s.id << ',' << s.name << ',' << s.course << ',' << s.email << '\n';
}
string ask(const string& prompt) { cout << prompt; string s; getline(cin,s); return s; }
string lower(string s) { transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return (char)tolower(c);}); return s; }
bool hasComma(const string& s) { return s.find(',') != string::npos; }
void show(const vector<Student>& rows) {
    if(rows.empty()) { cout << "No matching records found.\n"; return; }
    cout << "ID        NAME                   COURSE       EMAIL\n";
    cout << "--------------------------------------------------------------------\n";
    for(const auto& s:rows) cout << s.id << "    " << s.name << "    " << s.course << "    " << s.email << '\n';
}
int main() {
    auto rows=load();
    while(true) {
        cout << "\n=== STUDENT DATABASE SEARCH SYSTEM ===\n"
             << "1. Display all records\n2. Search records\n3. Add record\n"
             << "4. Update record\n5. Delete record\n0. Exit\n";
        string choice=ask("Choose an option: ");
        if(choice=="1") show(rows);
        else if(choice=="2") {
            string q=lower(ask("Search by ID, name, course, or email: "));
            vector<Student> found;
            for(const auto& s:rows)
                if(lower(s.id).find(q)!=string::npos || lower(s.name).find(q)!=string::npos ||
                   lower(s.course).find(q)!=string::npos || lower(s.email).find(q)!=string::npos) found.push_back(s);
            show(found);
        } else if(choice=="3") {
            Student s{ask("Student ID: "),ask("Name: "),ask("Course: "),ask("Email: ")};
            bool duplicate=any_of(rows.begin(),rows.end(),[&](const Student& x){return x.id==s.id;});
            if(s.id.empty()||s.name.empty()||s.course.empty()||s.email.empty()||duplicate||
               hasComma(s.id)||hasComma(s.name)||hasComma(s.course)||hasComma(s.email))
                cout << "Invalid or duplicate data. All fields are required; commas are not allowed.\n";
            else { rows.push_back(s); save(rows); cout << "Record added.\n"; }
        } else if(choice=="4") {
            string id=ask("ID to update: ");
            auto it=find_if(rows.begin(),rows.end(),[&](const Student& s){return s.id==id;});
            if(it==rows.end()) cout << "ID not found.\n";
            else {
                string v=ask("New name (blank keeps current): "); if(!v.empty()&&!hasComma(v)) it->name=v;
                v=ask("New course (blank keeps current): "); if(!v.empty()&&!hasComma(v)) it->course=v;
                v=ask("New email (blank keeps current): "); if(!v.empty()&&!hasComma(v)) it->email=v;
                save(rows); cout << "Record updated.\n";
            }
        } else if(choice=="5") {
            string id=ask("ID to delete: ");
            auto old=rows.size();
            rows.erase(remove_if(rows.begin(),rows.end(),[&](const Student& s){return s.id==id;}),rows.end());
            if(rows.size()==old) cout << "ID not found.\n";
            else { save(rows); cout << "Record deleted.\n"; }
        } else if(choice=="0") { cout << "Goodbye!\n"; break; }
        else cout << "Invalid option. Try again.\n";
    }
}
